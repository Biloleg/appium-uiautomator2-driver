/**
 * Chrome DevTools Protocol Client
 * Direct CDP connection to Oculus Browser, bypassing Chromedriver
 */

import WebSocket from 'ws';
import type { AppiumLogger } from '@appium/types';

export interface CDPCommand {
    id: number;
    method: string;
    params?: Record<string, any>;
}

export interface CDPResponse {
    id: number;
    result?: any;
    error?: {
        code: number;
        message: string;
    };
}

export interface CDPEvent {
    method: string;
    params?: Record<string, any>;
}

export interface CDPPage {
    id: string;
    type: string;
    title: string;
    url: string;
    webSocketDebuggerUrl: string;
    description?: string;
    devtoolsFrontendUrl?: string;
}

export class CDPClient {
    private ws: WebSocket | null = null;
    private messageId = 0;
    private pendingCommands: Map<number, { resolve: (value: any) => void; reject: (error: Error) => void }> = new Map();
    private eventHandlers: Map<string, Set<(params: any) => void>> = new Map();
    private logger: AppiumLogger;
    private localPort: number;
    private connected = false;
    private elementCache: Map<string, number> = new Map(); // Maps elementId -> nodeId
    private elementIdCounter = 0;

    constructor(localPort: number, logger: AppiumLogger) {
        this.localPort = localPort;
        this.logger = logger;
    }

    /**
     * Connect to CDP WebSocket endpoint
     */
    async connect(wsUrl: string): Promise<void> {
        this.logger.info(`[CDP] Connecting to: ${wsUrl}`);

        return new Promise((resolve, reject) => {
            this.ws = new WebSocket(wsUrl);

            this.ws.on('open', () => {
                this.connected = true;
                this.logger.info('[CDP] WebSocket connection established');
                resolve();
            });

            this.ws.on('message', (data: WebSocket.Data) => {
                this._handleMessage(data.toString());
            });

            this.ws.on('error', (error) => {
                this.logger.error(`[CDP] WebSocket error: ${error.message}`);
                reject(error);
            });

            this.ws.on('close', () => {
                this.connected = false;
                this.logger.info('[CDP] WebSocket connection closed');
            });
        });
    }

    /**
     * Handle incoming CDP messages
     */
    private _handleMessage(data: string): void {
        try {
            const message = JSON.parse(data);

            // Response to a command
            if ('id' in message && this.pendingCommands.has(message.id)) {
                const { resolve, reject } = this.pendingCommands.get(message.id)!;
                this.pendingCommands.delete(message.id);

                if (message.error) {
                    reject(new Error(`CDP Error: ${message.error.message}`));
                } else {
                    resolve(message.result || {});
                }
            }
            // Event notification
            else if ('method' in message) {
                const handlers = this.eventHandlers.get(message.method);
                if (handlers) {
                    for (const handler of handlers) {
                        handler(message.params || {});
                    }
                }
            }
        } catch (error) {
            this.logger.error(`[CDP] Failed to parse message: ${error}`);
        }
    }

    /**
     * Send CDP command and wait for response
     */
    async sendCommand(method: string, params?: Record<string, any>): Promise<any> {
        if (!this.ws || !this.connected) {
            throw new Error('CDP WebSocket not connected');
        }

        this.messageId++;
        const id = this.messageId;

        const command: CDPCommand = { id, method };
        if (params) {
            command.params = params;
        }

        return new Promise((resolve, reject) => {
            this.pendingCommands.set(id, { resolve, reject });

            this.ws!.send(JSON.stringify(command), (error) => {
                if (error) {
                    this.pendingCommands.delete(id);
                    reject(error);
                }
            });

            // Timeout after 30 seconds
            setTimeout(() => {
                if (this.pendingCommands.has(id)) {
                    this.pendingCommands.delete(id);
                    reject(new Error(`CDP command timeout: ${method}`));
                }
            }, 30000);
        });
    }

    /**
     * Subscribe to CDP events
     */
    on(event: string, handler: (params: any) => void): void {
        if (!this.eventHandlers.has(event)) {
            this.eventHandlers.set(event, new Set());
        }
        this.eventHandlers.get(event)!.add(handler);
    }

    /**
     * Unsubscribe from CDP events
     */
    off(event: string, handler: (params: any) => void): void {
        const handlers = this.eventHandlers.get(event);
        if (handlers) {
            handlers.delete(handler);
        }
    }

    /**
     * Navigate to URL
     */
    async navigate(url: string): Promise<void> {
        this.logger.info(`[CDP] Navigating to: ${url}`);
        await this.sendCommand('Page.navigate', { url });
    }

    /**
     * Execute JavaScript
     */
    async executeScript(script: string, awaitPromise = false): Promise<any> {
        const result = await this.sendCommand('Runtime.evaluate', {
            expression: script,
            returnByValue: true,
            awaitPromise,
        });

        if (result.exceptionDetails) {
            throw new Error(`Script execution failed: ${JSON.stringify(result.exceptionDetails)}`);
        }

        return result.result?.value;
    }

    /**
     * Execute JavaScript with arguments
     * Wraps the script to make 'arguments' available
     */
    async executeScriptWithArgs(script: string, args: any[] = []): Promise<any> {
        // JSON.stringify handles basic types. For DOM elements, we would need complexity.
        const safeArgs = JSON.stringify(args);

        // Wrap script to support 'arguments'
        // Handle explicit 'return' if present, similar to how Selenium does it
        // Note: This is an approximation.

        const expression = `
            (function() { 
                var arguments = ${safeArgs}; 
                ${script} 
            })()
        `;

        return await this.executeScript(expression);
    }

    /**
     * Get page title
     */
    async getTitle(): Promise<string> {
        return await this.executeScript('document.title');
    }

    /**
     * Get page URL
     */
    async getUrl(): Promise<string> {
        return await this.executeScript('document.location.href');
    }

    /**
     * Get page source
     */
    async getPageSource(): Promise<string> {
        return await this.executeScript('document.documentElement.outerHTML');
    }

    /**
     * Get window rectangle dimensions
     */
    async getWindowRect(): Promise<{ x: number; y: number; width: number; height: number }> {
        const rect = await this.executeScript(`({
            x: 0,
            y: 0,
            width: window.innerWidth,
            height: window.innerHeight
        })`);
        return rect;
    }

    /**
     * Build DOM-based element tree with coordinates
     * Returns XML structure compatible with Appium page source
     * Coordinates account for scroll position and device pixel ratio
     */
    async getDOMElementTree(): Promise<string> {
        // Enable DOM domain and get the full document
        await this.sendCommand('DOM.enable');
        const doc = await this.sendCommand('DOM.getDocument', { depth: -1, pierce: true });

        // Clear element cache before building new tree
        this.elementCache.clear();
        this.elementIdCounter = 0;

        // Get scroll position and DPR via JavaScript
        const scrollAndDpr = await this.executeScript(`({
            scrollX: window.scrollX || window.pageXOffset || 0,
            scrollY: window.scrollY || window.pageYOffset || 0,
            dpr: window.devicePixelRatio || 1
        })`);

        const buildNode = async (node: any, depth = 0): Promise<string> => {
            if (depth > 50 || !node || node.nodeType !== 1) return ''; // Only process element nodes

            const nodeId = node.nodeId;
            const tagName = (node.nodeName || '').toLowerCase();

            // Skip script, style, and other non-visual elements
            if (['script', 'style', 'noscript', 'meta', 'link', 'title'].includes(tagName)) {
                return '';
            }

            // Generate and cache element ID
            const elementId = this.generateElementId();
            this.elementCache.set(elementId, nodeId);

            // Get element's bounding box
            let bounds = { left: 0, top: 0, right: 0, bottom: 0 };
            try {
                const boxModel = await this.sendCommand('DOM.getBoxModel', { nodeId });
                if (boxModel && boxModel.model && boxModel.model.border) {
                    const border = boxModel.model.border;
                    // border is an array of 8 numbers: [x1, y1, x2, y2, x3, y3, x4, y4]
                    const left = Math.min(border[0], border[6]);
                    const top = Math.min(border[1], border[3]);
                    const right = Math.max(border[2], border[4]);
                    const bottom = Math.max(border[5], border[7]);

                    // Apply scroll offset and DPR
                    bounds = {
                        left: Math.round((left + scrollAndDpr.scrollX) * scrollAndDpr.dpr),
                        top: Math.round((top + scrollAndDpr.scrollY) * scrollAndDpr.dpr),
                        right: Math.round((right + scrollAndDpr.scrollX) * scrollAndDpr.dpr),
                        bottom: Math.round((bottom + scrollAndDpr.scrollY) * scrollAndDpr.dpr)
                    };
                }
            } catch (e) {
                // Element might not have a box model (display: none, etc.)
            }

            // Get attributes
            const attributes = node.attributes || [];
            const attrMap: any = {};
            for (let i = 0; i < attributes.length; i += 2) {
                const attrName = attributes[i];
                // Skip elementId attribute from the DOM as we generate our own
                if (attrName !== 'elementId') {
                    attrMap[attrName] = attributes[i + 1] || '';
                }
            }

            const className = attrMap.class || '';
            const id = attrMap.id || '';
            const ariaLabel = attrMap['aria-label'] || attrMap.title || '';
            const type = attrMap.type || '';

            // Get text content for this node only (not descendants)
            let text = '';
            if (node.children) {
                for (const child of node.children) {
                    if (child.nodeType === 3) { // Text node
                        text += (child.nodeValue || '');
                    }
                }
            }
            text = text.substring(0, 100).replace(/"/g, '&quot;').replace(/\n/g, ' ').trim();

            const width = bounds.right - bounds.left;
            const height = bounds.bottom - bounds.top;

            const xmlAttrs = [
                `class="${className}"`,
                `resource-id="${id}"`,
                `elementId="${elementId}"`,
                `text="${text}"`,
                `content-desc="${ariaLabel}"`,
                `checkable="${type === 'checkbox' || type === 'radio'}"`,
                `checked="false"`,
                `clickable="${['button', 'a', 'input'].includes(tagName)}"`,
                `enabled="true"`,
                `focusable="${attrMap.tabindex !== undefined}"`,
                `focused="false"`,
                `scrollable="false"`,
                `selected="false"`,
                `displayed="${width > 0 && height > 0}"`,
                `bounds="[${bounds.left},${bounds.top}][${bounds.right},${bounds.bottom}]"`,
                `x="${bounds.left}"`,
                `y="${bounds.top}"`,
                `width="${width}"`,
                `height="${height}"`
            ].join(' ');

            // Process children
            let childrenXml = '';
            if (node.children) {
                for (const child of node.children) {
                    childrenXml += await buildNode(child, depth + 1);
                }
            }

            return `<${tagName} ${xmlAttrs}>${childrenXml}</${tagName}>`;
        };

        // Find body node
        let bodyNode = null;
        const findBody = (node: any): any => {
            if (node.nodeName === 'BODY') return node;
            if (node.children) {
                for (const child of node.children) {
                    const result = findBody(child);
                    if (result) return result;
                }
            }
            return null;
        };

        bodyNode = findBody(doc.root);
        if (!bodyNode) {
            return '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?>\n<hierarchy rotation="0">\n</hierarchy>';
        }

        const bodyXml = await buildNode(bodyNode);
        return `<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>\n<hierarchy rotation="0">\n${bodyXml}\n</hierarchy>`;
    }

    /**
     * Generate a WebDriver-compatible element ID
     */
    private generateElementId(): string {
        this.elementIdCounter++;
        return `cdp-element-${this.elementIdCounter}`;
    }

    /**
     * Store element in cache and return WebDriver element object
     */
    private cacheElement(nodeId: number): any {
        const elementId = this.generateElementId();
        this.elementCache.set(elementId, nodeId);
        return {
            'ELEMENT': elementId,
            'element-6066-11e4-a52e-4f735466cecf': elementId
        };
    }

    /**
     * Get nodeId from element ID
     */
    getNodeId(elementId: string): number | undefined {
        return this.elementCache.get(elementId);
    }

    /**
     * Find element using CDP DOM.querySelector
     */
    async findElementByStrategy(strategy: string, selector: string): Promise<any> {
        // Enable DOM domain if not already enabled
        await this.sendCommand('DOM.enable');

        // Get document root
        const { root } = await this.sendCommand('DOM.getDocument', { depth: 0 });

        let nodeId: number;

        if (strategy === 'css selector') {
            // Use DOM.querySelector for CSS selectors
            const result = await this.sendCommand('DOM.querySelector', {
                nodeId: root.nodeId,
                selector: selector
            });
            nodeId = result.nodeId;
        } else if (strategy === 'xpath') {
            // For XPath, use Runtime.evaluate
            const result = await this.executeScript(
                `(function() {
                    const result = document.evaluate(
                        '${selector.replace(/'/g, "\\'")}',
                        document,
                        null,
                        XPathResult.FIRST_ORDERED_NODE_TYPE,
                        null
                    );
                    return result.singleNodeValue;
                })()`
            );
            if (!result || !result.objectId) {
                throw new Error(`Element not found: ${selector}`);
            }
            // Get nodeId from the returned object
            const { nodeId: nId } = await this.sendCommand('DOM.requestNode', {
                objectId: result.objectId
            });
            nodeId = nId;
        } else {
            throw new Error(`Unsupported locator strategy: ${strategy}`);
        }

        if (!nodeId || nodeId === 0) {
            throw new Error(`Element not found: ${selector}`);
        }

        return this.cacheElement(nodeId);
    }

    /**
     * Find multiple elements using CDP
     */
    async findElementsByStrategy(strategy: string, selector: string): Promise<any[]> {
        await this.sendCommand('DOM.enable');
        const { root } = await this.sendCommand('DOM.getDocument', { depth: 0 });

        let nodeIds: number[] = [];

        if (strategy === 'css selector') {
            const result = await this.sendCommand('DOM.querySelectorAll', {
                nodeId: root.nodeId,
                selector: selector
            });
            nodeIds = result.nodeIds || [];
        } else if (strategy === 'xpath') {
            const result = await this.executeScript(
                `(function() {
                    const result = document.evaluate(
                        '${selector.replace(/'/g, "\\'")}',
                        document,
                        null,
                        XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
                        null
                    );
                    const nodes = [];
                    for (let i = 0; i < result.snapshotLength; i++) {
                        nodes.push(result.snapshotItem(i));
                    }
                    return nodes;
                })()`
            );
            // Convert objects to nodeIds
            if (result && Array.isArray(result)) {
                for (const obj of result) {
                    if (obj && obj.objectId) {
                        const { nodeId } = await this.sendCommand('DOM.requestNode', {
                            objectId: obj.objectId
                        });
                        if (nodeId) nodeIds.push(nodeId);
                    }
                }
            }
        } else {
            throw new Error(`Unsupported locator strategy: ${strategy}`);
        }

        return nodeIds.filter(id => id !== 0).map(nodeId => this.cacheElement(nodeId));
    }

    /**
     * Get element attribute using nodeId
     */
    async getElementAttribute(elementId: string, attributeName: string): Promise<string | null> {
        const nodeId = this.getNodeId(elementId);
        if (!nodeId) {
            throw new Error(`Element not found in cache: ${elementId}`);
        }

        const { attributes } = await this.sendCommand('DOM.getAttributes', { nodeId });

        // Attributes come as [name1, value1, name2, value2, ...]
        for (let i = 0; i < attributes.length; i += 2) {
            if (attributes[i] === attributeName) {
                return attributes[i + 1];
            }
        }

        return null;
    }

    /**
     * Get element text using nodeId
     */
    async getElementText(elementId: string): Promise<string> {
        const nodeId = this.getNodeId(elementId);
        if (!nodeId) {
            throw new Error(`Element not found in cache: ${elementId}`);
        }

        const result = await this.sendCommand('DOM.resolveNode', { nodeId });
        if (!result || !result.object || !result.object.objectId) {
            return '';
        }

        // Use Runtime.callFunctionOn to call textContent getter on the object
        const textResult = await this.sendCommand('Runtime.callFunctionOn', {
            objectId: result.object.objectId,
            functionDeclaration: 'function() { return this.textContent || ""; }',
            returnByValue: true
        });

        if (textResult.exceptionDetails) {
            throw new Error(`Failed to get element text: ${JSON.stringify(textResult.exceptionDetails)}`);
        }

        return textResult.result?.value || '';
    }

    /**
     * Click element using nodeId
     */
    async clickElement(elementId: string): Promise<void> {
        const nodeId = this.getNodeId(elementId);
        if (!nodeId) {
            throw new Error(`Element not found in cache: ${elementId}`);
        }

        const result = await this.sendCommand('DOM.resolveNode', { nodeId });
        if (!result || !result.object || !result.object.objectId) {
            throw new Error('Failed to resolve element');
        }

        // Use Runtime.callFunctionOn to click the element
        const clickResult = await this.sendCommand('Runtime.callFunctionOn', {
            objectId: result.object.objectId,
            functionDeclaration: 'function() { this.click(); }',
            returnByValue: false
        });

        if (clickResult.exceptionDetails) {
            throw new Error(`Failed to click element: ${JSON.stringify(clickResult.exceptionDetails)}`);
        }
    }

    /**
     * Find element by CSS selector (legacy method)
     */
    async findElement(selector: string): Promise<any> {
        const result = await this.executeScript(
            `(function() {
        const el = document.querySelector('${selector.replace(/'/g, "\\'")}');
        if (!el) return null;
        return {
          tagName: el.tagName,
          id: el.id,
          className: el.className,
          text: el.textContent,
        };
      })()`
        );

        if (!result) {
            throw new Error(`Element not found: ${selector}`);
        }

        return result;
    }

    /**
     * Click element by CSS selector
     */
    async click(selector: string): Promise<void> {
        await this.executeScript(`document.querySelector('${selector.replace(/'/g, "\\'")}').click()`);
    }

    /**
     * Click at specific coordinates
     */
    async clickAtCoordinates(x: number, y: number): Promise<void> {
        await this.sendCommand('Input.dispatchMouseEvent', {
            type: 'mousePressed',
            x,
            y,
            button: 'left',
            clickCount: 1
        });
        await this.sendCommand('Input.dispatchMouseEvent', {
            type: 'mouseReleased',
            x,
            y,
            button: 'left',
            clickCount: 1
        });
    }

    /**
     * Find element by XPath and return its bounds
     */
    async findElementByXPath(xpath: string): Promise<{ x: number; y: number; width: number; height: number } | null> {
        const script = `
            (function() {
                const result = document.evaluate('${xpath.replace(/'/g, "\\'")}', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                const el = result.singleNodeValue;
                if (!el) return null;
                const rect = el.getBoundingClientRect();
                const dpr = window.devicePixelRatio || 1;
                return {
                    x: Math.round((rect.left + window.scrollX) * dpr),
                    y: Math.round((rect.top + window.scrollY) * dpr),
                    width: Math.round(rect.width * dpr),
                    height: Math.round(rect.height * dpr)
                };
            })()
        `;
        return await this.executeScript(script);
    }

    /**
     * Get element text
     */
    async getText(selector: string): Promise<string> {
        return await this.executeScript(`document.querySelector('${selector.replace(/'/g, "\\'")}').textContent`);
    }

    /**
     * Set element value
     */
    async setValue(selector: string, value: string): Promise<void> {
        await this.executeScript(
            `(function() {
        const el = document.querySelector('${selector.replace(/'/g, "\\'")}');
        el.value = '${value.replace(/'/g, "\\'")}';
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      })()`
        );
    }

    /**
     * Take screenshot
     */
    async takeScreenshot(): Promise<string> {
        const result = await this.sendCommand('Page.captureScreenshot', {
            format: 'png',
        });
        return result.data;
    }

    /**
     * Enable domains
     */
    async enableDomains(): Promise<void> {
        await Promise.all([
            this.sendCommand('Page.enable'),
            this.sendCommand('Runtime.enable'),
            this.sendCommand('DOM.enable'),
        ]);
    }

    /**
     * Close connection
     */
    async close(): Promise<void> {
        if (this.ws) {
            this.ws.close();
            this.ws = null;
            this.connected = false;
            this.pendingCommands.clear();
            this.eventHandlers.clear();
        }
    }

    /**
     * Check if connected
     */
    isConnected(): boolean {
        return this.connected;
    }
}

/**
 * Get available CDP pages from the browser
 */
export async function getCDPPages(port: number): Promise<CDPPage[]> {
    const url = `http://127.0.0.1:${port}/json`;
    const axios = (await import('axios')).default;
    const response = await axios.get(url);
    return response.data as CDPPage[];
}
